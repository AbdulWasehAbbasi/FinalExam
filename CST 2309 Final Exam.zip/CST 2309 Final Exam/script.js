document.getElementById('calculateBtn').addEventListener('click', function () {
    const principal = parseFloat(document.getElementById('principal').value);
    const monthlyInvestment = parseFloat(document.getElementById('monthlyInvestment').value);
    const annualRate = parseFloat(document.getElementById('rate').value) / 100;
    const years = parseInt(document.getElementById('years').value);

    if (isNaN(principal) || isNaN(monthlyInvestment) || isNaN(annualRate) || isNaN(years)) {
        document.getElementById('result').textContent = "Please fill in all fields with valid values.";
        return;
    }

    const months = years * 12;
    const monthlyRate = annualRate / 12;

    let futureValue = principal * Math.pow(1 + monthlyRate, months);

    for (let i = 1; i <= months; i++) {
        futureValue += monthlyInvestment * Math.pow(1 + monthlyRate, months - i);
    }

    document.getElementById('result').textContent = `Future Value: $${futureValue.toFixed(2)}`;
});
